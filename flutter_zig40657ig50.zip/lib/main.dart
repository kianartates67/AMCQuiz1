import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp( // #1 Root Material app: sets up app-wide configuration, routes, and theme
      title: 'Route Demo',
      debugShowCheckedModeBanner: false,
      routes: <String, WidgetBuilder>{
        '/': (BuildContext context) {
          return Scaffold( // #2 Page structure: provides layout for app bar and body
            appBar: AppBar( // #3 Top app bar: displays title and actions
              title: const Text('Home Route'), // #4 Text widget: displays readable text on the AppBar
            ),
            body: Center( // #7 Centers its child widget on the screen
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pushNamed(context, '/about');
                },
                child: const Text('Go to About'), // #4 Text widget: label shown on the button
              ),
            ),
          );
        },
        '/about': (BuildContext context) {
          return Scaffold( // #2 Page structure: layout container for the About screen
            appBar: AppBar( // #3 Top app bar for the About page
              title: const Text('About Route'), // #4 Text widget: title text for About page
            ),
            body: Center( // #7 Centers the button vertically and horizontally
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('Back to Home'), // #4 Text widget: button label text
              ),
            ),
          );
        },
      },
    );
  }
}
